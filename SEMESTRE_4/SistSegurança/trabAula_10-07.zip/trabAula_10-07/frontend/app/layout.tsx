import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Limpeza em Acao | Materiais", description: "Controle de materiais da equipe" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
