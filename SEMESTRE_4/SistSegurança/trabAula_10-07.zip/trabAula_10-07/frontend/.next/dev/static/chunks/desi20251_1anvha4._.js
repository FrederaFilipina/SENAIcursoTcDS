(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1mojsay._.js","static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1q7vymv._.js","static/chunks/1i7g_next_dist_compiled_next-devtools_index_05uitep.js","static/chunks/1i7g_next_dist_compiled_react-dom_0s3epu3._.js","static/chunks/1i7g_next_dist_compiled_react-server-dom-turbopack_1bf6r4x._.js","static/chunks/1i7g_next_dist_compiled_0rzfala._.js","static/chunks/1i7g_next_dist_client_0zqbg_x._.js","static/chunks/1i7g_next_dist_1lroqyv._.js","static/chunks/1i7g_@swc_helpers_cjs_1ojz-w0._.js"],
    source: "entry"
});
