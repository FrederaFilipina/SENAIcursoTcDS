(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/desi20251_app_globals_1imr4pr.css","static/chunks/1i7g_next_dist_1rm4zcc._.js","static/chunks/1i7g_1--1-uq._.js","static/chunks/desi20251_app_1l680iu._.js"],
    source: "entry"
});
